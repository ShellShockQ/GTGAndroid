package com.gametimegiving.android.Helpers;

/**
 * Created by Administrator on 11/20/2017.
 */

public interface FancyGifDialogListener {
    void OnClick();
}
